import cherrypy
import pymysql
from main import connect
import os
from mako.template import Template
from mako.lookup import TemplateLookup

# Configuration du répertoire de templates Mako
mylookup = TemplateLookup(directories=['html/'], input_encoding='utf-8', module_directory='ressources/tmp/mako_modules')

class InterfaceWebClub(object):

    @cherrypy.expose
    def index(self):
        mytemplate = mylookup.get_template("index.html")
        return mytemplate.render()

    @cherrypy.expose
    def creation(self):
        mytemplate = mylookup.get_template("creation.html")
        return mytemplate.render()
    
    @cherrypy.expose
    def affichage(self):
        mytemplate = mylookup.get_template("affichage.html")
        return mytemplate.render()
    
    @cherrypy.expose
    def suppression(self):
        mytemplate = mylookup.get_template("supp.html")
        return mytemplate.render()
    


    # Fonctions de création

    @cherrypy.expose
    def ajoutSeance(self, nom_seance=None, materiel=None, duree=None, nom_exercice1=None, nom_exercice2=None, nom_exercice3=None):
        if materiel is None or duree is None:
            mytemplate = mylookup.get_template("ajoutSeance.html")
            return mytemplate.render(page_title="Création", message="Veuillez remplir tous les champs.")
        
        try:
            duree = int(duree)
            if duree < 0:
                raise ValueError("La durée ne peut pas être négative.")
        except ValueError as ve:
            mytemplate = mylookup.get_template("ajoutSeance.html")
            return mytemplate.render(page_title="Création", message=str(ve))
        
        
        db, cursor = connect()
        message = ""
        if db and cursor:
            try:
                # Vérifier si la séance existe déjà
                cursor.execute("SELECT COUNT(*) FROM seance WHERE nom_seance = %s", (nom_seance))
                result = cursor.fetchone()
                if result[0] > 0:
                    message = f"La séance '{nom_seance}' existe déjà dans la base de données."
                else:
                    # Ajouter la séance
                    cursor.execute("INSERT INTO seance (nom_seance, materiel, duree) VALUES (%s, %s, %s)", (nom_seance, materiel, duree))
                    seance_id = cursor.lastrowid

                    # Ajouter les exercices et les lier à la séance
                    exercices_a_ajouter = [nom_exercice1, nom_exercice2, nom_exercice3]
                    if nom_exercice1 == nom_exercice2 or nom_exercice2 == nom_exercice3 or nom_exercice1 == nom_exercice3:
                        message = f"Les exercices ne doivent pas étre pareil !"
                    else:
                        for index, nom_exercice in enumerate(exercices_a_ajouter, start=1):
                            if nom_exercice:
                                cursor.execute("INSERT INTO exercice (nom) VALUES (%s)", (nom_exercice))
                                exercice_id = cursor.lastrowid
                                cursor.execute(f"UPDATE seance SET NumExercice_{index} = %s WHERE NumSeance = %s", (exercice_id, seance_id))

                        db.commit()
                        message = "La séance a été ajoutée avec succès."
            except pymysql.Error as e:
                message = f"Erreur lors de l'exécution de la requête SQL: {e}"
            finally:
                cursor.close()
                db.close()
        
        # Rendre la template avec le message approprié
        mytemplate = mylookup.get_template("ajoutSeance.html")
        return mytemplate.render(page_title="Création", message=message)


    @cherrypy.expose
    def ajoutExo(self, nom=None):
        if nom is None:
            mytemplate = mylookup.get_template("ajoutExo.html")
            return mytemplate.render(page_title="Création", message="Veuillez fournir le nom de l'exercice.")
        
        db,cursor = connect()
        message = ""
        if db and cursor:
            try:
                cursor.execute("SELECT COUNT(*) FROM exercice WHERE nom = %s", (nom))
                result = cursor.fetchone()
                if result[0] > 0:
                    message = f"L'exercice '{nom}' existe déjà dans la base de données."
                else:
                    # Ajouter l'exercice
                    cursor.execute("INSERT INTO `exercice` (nom) VALUES (%s)", (nom))
                    db.commit()
                    message = "L'exercice a été ajouté avec succès."

            except pymysql.Error as e:
                message = f"Erreur lors de l'exécution de la requête SQL: {e}"
            finally:
                cursor.close()
                db.close()
        
        mytemplate = mylookup.get_template("ajoutExo.html")
        return mytemplate.render(page_title="Création", message=message)

    # Fonctions d'affichage

    @cherrypy.expose
    def listeSeance(self):
        db, cursor = connect()
        try:
            cursor.execute("SELECT * FROM seance")
            resultats = cursor.fetchall()
            mytemplate = mylookup.get_template("listeSeance.html")
            return mytemplate.render(seances=resultats)
        except pymysql.Error as e:
            message = "Erreur lors de l'exécution de la requête SQL: {}".format(e)
            mytemplate = mylookup.get_template("message.html")
            return mytemplate.render(message=message)
        finally:
            cursor.close()
            db.close()


    def getSeance(self):
        db, cursor = connect()
        cursor.execute("SELECT * FROM seance")
        resultats = cursor.fetchall()
        cursor.close()
        db.close()
        return resultats


    @cherrypy.expose
    def showExos(self):
        db, cursor = connect()
        try:
            cursor.execute("SELECT * FROM exercice")
            resultats = cursor.fetchall()
            mytemplate = mylookup.get_template("showExos.html")
            return mytemplate.render(exercices=resultats)
        except pymysql.Error as e:
            message = "Erreur lors de l'exécution de la requête SQL: {}".format(e)
            mytemplate = mylookup.get_template("message.html")
            return mytemplate.render(message=message)
        finally:
            cursor.close()
            db.close()

    # Fonctions de suppression

    @cherrypy.expose
    def suppressionSeance(self, nom_seance=None):
        message = None
        if nom_seance:
            db, cursor = connect()
            if db and cursor:
                try:
                    cursor.execute("DELETE FROM seance WHERE Nom_seance=%s", (nom_seance))
                    db.commit()
                    message = "La séance a été supprimée avec succès."
                except pymysql.Error as e:
                    message = "Erreur lors de l'exécution de la requête SQL: {}".format(e)
                finally:
                    cursor.close()
                    db.close()
            else:
                message = "Erreur de connexion à la base de données."
        else:
            message = "Veuillez spécifier le nom de la séance à supprimer."
        mytemplate = mylookup.get_template("suppressionSeance.html")
        return mytemplate.render(message=message)
    
    @cherrypy.expose
    def suppressionExo(self, nom_exercice=None):
        if nom_exercice:
            db, cursor = connect()
            if db and cursor:
                try:
                    # Vérifier d'abord si l'exercice existe
                    cursor.execute("SELECT COUNT(*) FROM exercice WHERE nom=%s", (nom_exercice))
                    count = cursor.fetchone()[0]
                    if count > 0:
                        cursor.execute("DELETE FROM exercice WHERE nom=%s", (nom_exercice))
                        db.commit()
                        message = "L'exercice a été supprimé avec succès."
                    else:
                        message = "L'exercice '{}' n'existe pas.".format(nom_exercice)
                except pymysql.Error as e:
                    message = "Erreur lors de l'exécution de la requête SQL: {}".format(e)
                finally:
                    cursor.close()
                    db.close()
            else:
                message = "Erreur de connexion à la base de données."
        else:
            message = "Veuillez spécifier le nom de l'exercice à supprimer."
        mytemplate = mylookup.get_template("suppressionExo.html")
        return mytemplate.render(message=message)

    # Fonction d'inscription


    @cherrypy.expose
    def inscription(self, nom=None, prenom=None, seance1=None):
        # Récupération de la liste des séances
        resultats = self.getSeance()

        if not nom or not prenom or not seance1:
            mytemplate = mylookup.get_template("inscription.html")
            return mytemplate.render(
                page_title="Inscription",
                message="Veuillez remplir tous les champs.",
                seances=resultats
            )

        db, cursor = connect()
        message = ""
        if db and cursor:
            try:
                # Insérer l'adhérent
                cursor.execute("INSERT INTO adherent (nom, prenom, NumSeance) VALUES (%s, %s, %s)", (nom, prenom, seance1))
                db.commit()

                # Récupérer l'ID de la dernière ligne insérée
                cursor.execute("SELECT LAST_INSERT_ID()")
                last_row_id = cursor.fetchone()[0]

                message = "L'adhérent et les séances ont été ajoutés avec succès. ID de l'adhérent: {}".format(last_row_id)
            except pymysql.Error as e:
                message = f"Erreur lors de l'exécution de la requête SQL: {e}"
            finally:
                cursor.close()
                db.close()

        mytemplate = mylookup.get_template("inscription.html")
        return mytemplate.render(page_title="Inscription", message=message, seances=resultats)



if __name__ == '__main__':
    rootPath = os.path.abspath(os.getcwd())
    cherrypy.config.update({'tools.encode.encoding': 'utf-8'})
    conf = {
        '/': {
            'tools.staticdir.on': True,
            'tools.staticdir.dir': 'html',
            'tools.staticdir.root': rootPath
        },
        '/css': {
            'tools.staticdir.on': True,
            'tools.staticdir.dir': './css'
        },
        '/images': {
            'tools.staticdir.on': True,
            'tools.staticdir.dir': './images'
        }
    }
    cherrypy.quickstart(InterfaceWebClub(), '/', config=conf)
