-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mar. 04 juin 2024 à 08:08
-- Version du serveur : 8.2.0
-- Version de PHP : 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `club`
--

-- --------------------------------------------------------

--
-- Structure de la table `adherent`
--

DROP TABLE IF EXISTS `adherent`;
CREATE TABLE IF NOT EXISTS `adherent` (
  `NumAdherent` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `NumSeance` int DEFAULT NULL,
  PRIMARY KEY (`NumAdherent`),
  KEY `NumSeance` (`NumSeance`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `adherent`
--

INSERT INTO `adherent` (`NumAdherent`, `nom`, `prenom`, `NumSeance`) VALUES
(12, 'abdel', 'abbf', 15),
(13, 'iozjfg', 'ltk', 16),
(14, 'ilysse', 'kebaili', 15),
(15, 'ismael', 'bfizffzifnzfnz', 17),
(16, 'Timech', ' Abdel', 25),
(17, 'Doe', ' John', 26),
(18, 'Smith', ' Amy', 27),
(19, 'Johnson', ' Emily', 28),
(20, 'Martinez', ' Carlos', 29),
(21, 'Kim', ' Minho', 30),
(22, 'Williams', ' Jessica', 31),
(23, 'Brown', ' Sarah', 32),
(24, 'Jones', ' Michael', 33),
(25, 'Garcia', ' Maria', 34),
(26, 'Lee', ' David', 35),
(27, 'Rodriguez', ' Sofia', 36),
(28, 'Nguyen', ' Alex', 37),
(29, 'Hall', ' Emma', 38),
(30, 'Thomas', ' Olivia', 39),
(31, 'Walker', ' Daniel', 40),
(32, 'Wilson', ' Michelle', 41),
(33, 'Evans', ' Matthew', 42),
(34, 'Baker', ' Lauren', 43),
(35, 'White', ' Ryan', 44),
(36, 'Timech', ' Abdel', 45),
(37, 'Doe', ' John', 46),
(38, 'Smith', ' Amy', 47),
(39, 'Johnson', ' Emily', 48),
(40, 'Martinez', ' Carlos', 49),
(41, 'Kim', ' Minho', 50),
(42, 'Williams', ' Jessica', 51),
(43, 'Brown', ' Sarah', 52),
(44, 'Jones', ' Michael', 53),
(45, 'Garcia', ' Maria', 54),
(46, 'Lee', ' David', 55),
(47, 'Rodriguez', ' Sofia', 56),
(48, 'Nguyen', ' Alex', 57),
(49, 'Hall', ' Emma', 58),
(50, 'Thomas', ' Olivia', 59),
(51, 'Walker', ' Daniel', 60),
(52, 'Wilson', ' Michelle', 61),
(53, 'Evans', ' Matthew', 62),
(54, 'Baker', ' Lauren', 63),
(55, 'White', ' Ryan', 64),
(56, 'Timech', ' Abdel', 65),
(57, 'Doe', ' John', 66),
(58, 'Smith', ' Amy', 67),
(59, 'Johnson', ' Emily', 68),
(60, 'Martinez', ' Carlos', 69),
(61, 'Kim', ' Minho', 70),
(62, 'Williams', ' Jessica', 71),
(63, 'Brown', ' Sarah', 72),
(64, 'Jones', ' Michael', 73),
(65, 'Garcia', ' Maria', 74),
(66, 'Lee', ' David', 75),
(67, 'Rodriguez', ' Sofia', 76),
(68, 'Nguyen', ' Alex', 77),
(69, 'Hall', ' Emma', 78),
(70, 'Thomas', ' Olivia', 79),
(71, 'Walker', ' Daniel', 80),
(72, 'Wilson', ' Michelle', 81),
(73, 'Evans', ' Matthew', 82),
(74, 'Baker', ' Lauren', 83),
(75, 'White', ' Ryan', 84);

-- --------------------------------------------------------

--
-- Structure de la table `exercice`
--

DROP TABLE IF EXISTS `exercice`;
CREATE TABLE IF NOT EXISTS `exercice` (
  `NumExercice` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  PRIMARY KEY (`NumExercice`)
) ENGINE=InnoDB AUTO_INCREMENT=244 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `exercice`
--

INSERT INTO `exercice` (`NumExercice`, `nom`) VALUES
(13, 'SHLAK'),
(14, 'DZDDZ'),
(15, 'fnie'),
(16, 'developpe couhe'),
(17, 'pec fly'),
(18, 'squat'),
(19, 'developpe couhe'),
(20, 'pec fly'),
(21, 'squat'),
(22, 'developpe couhe'),
(23, 'pec fly'),
(24, 'squat'),
(25, 'developpe couhe'),
(26, 'pec fly'),
(27, 'squat'),
(28, 'developpe couhe'),
(29, 'pec fly'),
(30, 'squat'),
(31, 'developpe couhe'),
(32, 'pec fly'),
(33, 'squat'),
(34, 'developpe couhe'),
(35, 'pec fly'),
(36, 'squat'),
(37, 'developpe couhe'),
(38, 'pec fly'),
(39, 'squat'),
(40, 'developpe couhe'),
(41, 'pec fly'),
(42, 'squat'),
(43, 'developpe couhe'),
(44, 'pec fly'),
(45, 'squat'),
(46, 'af'),
(47, 'ggnbn'),
(48, 'bn'),
(49, 'rgg'),
(50, 'rgg'),
(51, 'znng'),
(52, 'znng'),
(53, 'grphk'),
(54, 'yjj'),
(55, 'kbfg'),
(56, 'kaiting'),
(57, 'wave menagement'),
(58, 'set up objectif'),
(59, 'a'),
(60, 'b'),
(61, 'c'),
(62, 'b'),
(63, 'flzjojjf'),
(64, ' curl'),
(65, ' pompes'),
(66, ' course'),
(67, ' abdos'),
(68, ' jump squats'),
(69, ' corde à sauter'),
(70, ' soulevé de terre'),
(71, ' planche'),
(72, ' escaliers'),
(73, ' lunges'),
(74, ' dips'),
(75, ' sprint'),
(76, ' crunches'),
(77, ' burpees'),
(78, ' natation'),
(79, ' deadlift'),
(80, ' plank'),
(81, ' cycling'),
(82, ' squats'),
(83, ' push-ups'),
(84, ' jogging'),
(85, ' mountain climbers'),
(86, ' box jumps'),
(87, ' elliptical'),
(88, ' leg press'),
(89, ' sit-ups'),
(90, ' rowing'),
(91, ' Russian twists'),
(92, ' jumping jacks'),
(93, ' cycling'),
(94, ' leg raises'),
(95, ' kettlebell swings'),
(96, ' running'),
(97, ' plank jacks'),
(98, ' jump rope'),
(99, ' swimming'),
(100, ' bench press'),
(101, ' side planks'),
(102, ' stair climbing'),
(103, ' bicep curls'),
(104, ' tricep extensions'),
(105, ' rowing machine'),
(106, ' reverse crunches'),
(107, ' box squats'),
(108, ' stationary bike'),
(109, ' step-ups'),
(110, ' bicycle crunches'),
(111, ' sprinting'),
(112, ' leg lifts'),
(113, ' jump lunges'),
(114, ' trail running'),
(115, ' sit-up twists'),
(116, ' high knees'),
(117, ' cross-country skiing'),
(118, ' flutter kicks'),
(119, ' squat jumps'),
(120, ' treadmill'),
(121, ' plank variations'),
(122, ' shuttle runs'),
(123, ' rowing'),
(124, ' curl'),
(125, ' pompes'),
(126, ' course'),
(127, ' abdos'),
(128, ' jump squats'),
(129, ' corde à sauter'),
(130, ' soulevé de terre'),
(131, ' planche'),
(132, ' escaliers'),
(133, ' lunges'),
(134, ' dips'),
(135, ' sprint'),
(136, ' crunches'),
(137, ' burpees'),
(138, ' natation'),
(139, ' deadlift'),
(140, ' plank'),
(141, ' cycling'),
(142, ' squats'),
(143, ' push-ups'),
(144, ' jogging'),
(145, ' mountain climbers'),
(146, ' box jumps'),
(147, ' elliptical'),
(148, ' leg press'),
(149, ' sit-ups'),
(150, ' rowing'),
(151, ' Russian twists'),
(152, ' jumping jacks'),
(153, ' cycling'),
(154, ' leg raises'),
(155, ' kettlebell swings'),
(156, ' running'),
(157, ' plank jacks'),
(158, ' jump rope'),
(159, ' swimming'),
(160, ' bench press'),
(161, ' side planks'),
(162, ' stair climbing'),
(163, ' bicep curls'),
(164, ' tricep extensions'),
(165, ' rowing machine'),
(166, ' reverse crunches'),
(167, ' box squats'),
(168, ' stationary bike'),
(169, ' step-ups'),
(170, ' bicycle crunches'),
(171, ' sprinting'),
(172, ' leg lifts'),
(173, ' jump lunges'),
(174, ' trail running'),
(175, ' sit-up twists'),
(176, ' high knees'),
(177, ' cross-country skiing'),
(178, ' flutter kicks'),
(179, ' squat jumps'),
(180, ' treadmill'),
(181, ' plank variations'),
(182, ' shuttle runs'),
(183, ' rowing'),
(184, ' curl'),
(185, ' pompes'),
(186, ' course'),
(187, ' abdos'),
(188, ' jump squats'),
(189, ' corde à sauter'),
(190, ' soulevé de terre'),
(191, ' planche'),
(192, ' escaliers'),
(193, ' lunges'),
(194, ' dips'),
(195, ' sprint'),
(196, ' crunches'),
(197, ' burpees'),
(198, ' natation'),
(199, ' deadlift'),
(200, ' plank'),
(201, ' cycling'),
(202, ' squats'),
(203, ' push-ups'),
(204, ' jogging'),
(205, ' mountain climbers'),
(206, ' box jumps'),
(207, ' elliptical'),
(208, ' leg press'),
(209, ' sit-ups'),
(210, ' rowing'),
(211, ' Russian twists'),
(212, ' jumping jacks'),
(213, ' cycling'),
(214, ' leg raises'),
(215, ' kettlebell swings'),
(216, ' running'),
(217, ' plank jacks'),
(218, ' jump rope'),
(219, ' swimming'),
(220, ' bench press'),
(221, ' side planks'),
(222, ' stair climbing'),
(223, ' bicep curls'),
(224, ' tricep extensions'),
(225, ' rowing machine'),
(226, ' reverse crunches'),
(227, ' box squats'),
(228, ' stationary bike'),
(229, ' step-ups'),
(230, ' bicycle crunches'),
(231, ' sprinting'),
(232, ' leg lifts'),
(233, ' jump lunges'),
(234, ' trail running'),
(235, ' sit-up twists'),
(236, ' high knees'),
(237, ' cross-country skiing'),
(238, ' flutter kicks'),
(239, ' squat jumps'),
(240, ' treadmill'),
(241, ' plank variations'),
(242, ' shuttle runs'),
(243, ' rowing');

-- --------------------------------------------------------

--
-- Structure de la table `seance`
--

DROP TABLE IF EXISTS `seance`;
CREATE TABLE IF NOT EXISTS `seance` (
  `NumSeance` int NOT NULL AUTO_INCREMENT,
  `nom_seance` varchar(20) NOT NULL,
  `materiel` varchar(20) NOT NULL,
  `NumExercice_1` int DEFAULT NULL,
  `NumExercice_2` int DEFAULT NULL,
  `NumExercice_3` int DEFAULT NULL,
  `duree` int DEFAULT NULL,
  PRIMARY KEY (`NumSeance`),
  KEY `NumExercice_1` (`NumExercice_1`),
  KEY `NumExercice_2` (`NumExercice_2`),
  KEY `NumExercice_3` (`NumExercice_3`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `seance`
--

INSERT INTO `seance` (`NumSeance`, `nom_seance`, `materiel`, `NumExercice_1`, `NumExercice_2`, `NumExercice_3`, `duree`) VALUES
(5, 'AAAA', 'BBBB', 16, 17, 18, 7),
(6, 'AAAA', 'BBBB', 19, 20, 21, 7),
(7, 'AAAA', 'BBBB', 22, 23, 24, 7),
(8, 'AAAA', 'BBBB', 25, 26, 27, 7),
(9, 'AAAA', 'BBBB', 28, 29, 30, 7),
(10, 'AAAA', 'BBBB', 31, 32, 33, 7),
(11, 'AAAA', 'BBBB', 34, 35, 36, 7),
(12, 'AAAA', 'BBBB', 37, 38, 39, 7),
(13, 'AAAA', 'BBBB', 40, 41, 42, 7),
(14, 'AAAA', 'BBBB', 43, 44, 45, 7),
(15, 'b a', 'efgeg', 46, 47, 48, 2),
(16, 'czafzf', 'mltlgtj', 53, 54, 55, 3),
(17, 'league of legends ', 'clavier + cerveau ', 56, 57, 58, 60),
(19, 'A', 'A', NULL, NULL, NULL, 2),
(20, 'a', 'a', NULL, NULL, NULL, 3),
(21, 'a', 'a', NULL, NULL, NULL, 3),
(22, 'gh', 'v', 60, 61, 62, 2),
(25, '', ' haltere', 64, 65, 66, 60),
(26, '', ' barre de traction', 67, 68, 69, 45),
(27, '', ' haltères', 70, 71, 72, 55),
(28, '', ' kettlebell', 73, 74, 75, 50),
(29, '', ' poids corporel', 76, 77, 78, 40),
(30, '', ' barbell', 79, 80, 81, 55),
(31, '', ' dumbbell', 82, 83, 84, 60),
(32, '', ' TRX', 85, 86, 87, 45),
(33, '', ' resistance bands', 88, 89, 90, 50),
(34, '', ' medicine ball', 91, 92, 93, 55),
(35, '', ' pull-up bar', 94, 95, 96, 50),
(36, '', ' bodyweight', 97, 98, 99, 40),
(37, '', ' free weights', 100, 101, 102, 60),
(38, '', ' cable machine', 103, 104, 105, 45),
(39, '', ' sandbag', 106, 107, 108, 55),
(40, '', ' resistance tube', 109, 110, 111, 50),
(41, '', ' weighted vest', 112, 113, 114, 60),
(42, '', ' weighted ball', 115, 116, 117, 45),
(43, '', ' balance board', 118, 119, 120, 50),
(44, '', ' agility ladder', 121, 122, 123, 55),
(45, '', ' haltere', 124, 125, 126, 60),
(46, '', ' barre de traction', 127, 128, 129, 45),
(47, '', ' haltères', 130, 131, 132, 55),
(48, '', ' kettlebell', 133, 134, 135, 50),
(49, '', ' poids corporel', 136, 137, 138, 40),
(50, '', ' barbell', 139, 140, 141, 55),
(51, '', ' dumbbell', 142, 143, 144, 60),
(52, '', ' TRX', 145, 146, 147, 45),
(53, '', ' resistance bands', 148, 149, 150, 50),
(54, '', ' medicine ball', 151, 152, 153, 55),
(55, '', ' pull-up bar', 154, 155, 156, 50),
(56, '', ' bodyweight', 157, 158, 159, 40),
(57, '', ' free weights', 160, 161, 162, 60),
(58, '', ' cable machine', 163, 164, 165, 45),
(59, '', ' sandbag', 166, 167, 168, 55),
(60, '', ' resistance tube', 169, 170, 171, 50),
(61, '', ' weighted vest', 172, 173, 174, 60),
(62, '', ' weighted ball', 175, 176, 177, 45),
(63, '', ' balance board', 178, 179, 180, 50),
(64, '', ' agility ladder', 181, 182, 183, 55),
(65, '', ' haltere', 184, 185, 186, 60),
(66, '', ' barre de traction', 187, 188, 189, 45),
(67, '', ' haltères', 190, 191, 192, 55),
(68, '', ' kettlebell', 193, 194, 195, 50),
(69, '', ' poids corporel', 196, 197, 198, 40),
(70, '', ' barbell', 199, 200, 201, 55),
(71, '', ' dumbbell', 202, 203, 204, 60),
(72, '', ' TRX', 205, 206, 207, 45),
(73, '', ' resistance bands', 208, 209, 210, 50),
(74, '', ' medicine ball', 211, 212, 213, 55),
(75, '', ' pull-up bar', 214, 215, 216, 50),
(76, '', ' bodyweight', 217, 218, 219, 40),
(77, '', ' free weights', 220, 221, 222, 60),
(78, '', ' cable machine', 223, 224, 225, 45),
(79, '', ' sandbag', 226, 227, 228, 55),
(80, '', ' resistance tube', 229, 230, 231, 50),
(81, '', ' weighted vest', 232, 233, 234, 60),
(82, '', ' weighted ball', 235, 236, 237, 45),
(83, '', ' balance board', 238, 239, 240, 50),
(84, '', ' agility ladder', 241, 242, 243, 55);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `adherent`
--
ALTER TABLE `adherent`
  ADD CONSTRAINT `adherent_ibfk_1` FOREIGN KEY (`NumSeance`) REFERENCES `seance` (`NumSeance`) ON DELETE CASCADE;

--
-- Contraintes pour la table `seance`
--
ALTER TABLE `seance`
  ADD CONSTRAINT `seance_ibfk_1` FOREIGN KEY (`NumExercice_1`) REFERENCES `exercice` (`NumExercice`) ON DELETE CASCADE,
  ADD CONSTRAINT `seance_ibfk_2` FOREIGN KEY (`NumExercice_2`) REFERENCES `exercice` (`NumExercice`) ON DELETE CASCADE,
  ADD CONSTRAINT `seance_ibfk_3` FOREIGN KEY (`NumExercice_3`) REFERENCES `exercice` (`NumExercice`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
