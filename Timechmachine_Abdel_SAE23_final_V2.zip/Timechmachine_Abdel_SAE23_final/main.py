import pymysql


def connect():
        # Connexion à la base de données
        db = pymysql.connect(host='localhost', user='root', port=3306, password='', database='club')
        # Création d'un objet curseur
        cursor = db.cursor()
        # Renvoyer la connexion et le curseur
        return db, cursor




