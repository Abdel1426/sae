étapes pour utiliser l'interface web :

1) Modifier la fonction create_connect() du fichier crea.py

2) Creér la base grâce au fichier crea.py

3) Modifier la fonction connect du fichier main.py

4) Changer les options user et password avec les valeurs de votre base

La partie privée ce sont les onglets affichage, création et suppression tandis que la partie publique est l'onglet Inscription dans lequel 
un utilisateur peur s'inscrire à un séance.

Pour le fonctionalitées prévues mais qui n'ont pas été réaliser c'est la fonctionnalités d'inscription.

Par rapport au premier livrable il y'a eu des modifications sur les fonctions cli, en effet elles ont été modifier pour une
utilisation cherrypy.

L'archive contient 4 dossiers css, html et images leurs noms indique leur fonctionnalités,
le dossier contient les fichiers python suivants : ajoutCSV pour le jeu d'essai il est accompagner par le fichier CSV data.csv, le fichier crea.py qui sert à créer la base (n'oubliez pas de changer user et password), interfaceWEB.py qui contient le code cherrypy et enfin le fichier main qui contient la fonction connect qui vas être importer par le fichier interfaceWEB. le dernier fichier est club.sql qui sert pour le dump.

