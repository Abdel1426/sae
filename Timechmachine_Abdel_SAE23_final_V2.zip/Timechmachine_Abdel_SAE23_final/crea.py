import pymysql

creaBase = "CREATE DATABASE IF NOT EXISTS club;"

creaExercice = """CREATE TABLE IF NOT EXISTS exercice (
                        NumExercice INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL,
                        nom VARCHAR(100) NOT NULL
                    ) ENGINE=INNODB CHARSET='utf8';"""


creaSeance = """CREATE TABLE IF NOT EXISTS seance (
                        NumSeance INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL,
                        nom_seance VARCHAR(20) NOT NULL,
                        materiel VARCHAR(20) NOT NULL,
                        NumExercice_1 INTEGER,
                        NumExercice_2 INTEGER,
                        NumExercice_3 INTEGER,
                        duree INTEGER,
                        FOREIGN KEY (NumExercice_1) REFERENCES exercice(NumExercice) ON DELETE CASCADE,
                        FOREIGN KEY (NumExercice_2) REFERENCES exercice(NumExercice) ON DELETE CASCADE,
                        FOREIGN KEY (NumExercice_3) REFERENCES exercice(NumExercice) ON DELETE CASCADE
                    ) ENGINE=INNODB CHARSET='utf8';"""


creaAdherent = """CREATE TABLE IF NOT EXISTS adherent (
                        NumAdherent INTEGER PRIMARY KEY AUTO_INCREMENT NOT NULL,
                        nom VARCHAR(100) NOT NULL,
                        prenom VARCHAR(100) NOT NULL,
                        NumSeance INTEGER,
                        FOREIGN KEY (NumSeance) REFERENCES seance(NumSeance) ON DELETE CASCADE
                    ) ENGINE=INNODB CHARSET='utf8';"""


def create_and_connect():
    try:
        db = pymysql.connect(host='localhost', user='root', port=3306, password='Samymyrtille2711!')
        cursor = db.cursor()

        cursor.execute(creaBase)
        cursor.execute("USE club")

        cursor.execute(creaExercice)
        cursor.execute(creaSeance)
        cursor.execute(creaAdherent)

        db.commit()
    except pymysql.Error as e:
        print("Erreur lors de l'exécution de la requête MySQL :", e)
    finally:
        cursor.close()
        db.close()


def main():
    try:
        
        a = input("Voulez-vous créer la base club ? ")
        
        match a.lower():

            case "oui" | "o":
                print("Vous avez choisi d'utiliser cette méthode.")
                create_and_connect()
                print("La base de données et les tables ont été créées avec succès.")

            case _:
                print("Choix non valide. Veuillez choisir entre 'dump' ou 'méthode'.")
    except Exception as e:
        print("Une erreur s'est produite :", e)


if __name__ == "__main__":
    main()

