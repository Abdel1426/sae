# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1716540330.7342854
_enable_loop = True
_template_filename = 'html/ajoutExo.html'
_template_uri = 'ajoutExo.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        message = context.get('message', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <meta charset="UTF-8">\r\n    <link rel="stylesheet" type="text/css" href="../css/style2.css">\r\n    <title>Interface Web Club</title>\r\n</head>\r\n<body>\r\n\r\n    <ul>\r\n        <li><a href="index">Accueil</a></li>\r\n        <li class="dropdown">\r\n            <a href="javascript:void(0)" class="dropbtn">creation</a>\r\n            <div class="dropdown-content">\r\n                <a href="./">Ajouter un exercice</a>\r\n                <a href="ajoutSeance">Ajouter une séance</a>\r\n            </div>\r\n        </li>\r\n\r\n        <li class="dropdown">\r\n            <a href="javascript:void(0)" class="dropbtn">Affichage</a>\r\n            <div class="dropdown-content">\r\n                <a href="listeSeance">Affichage des séances</a>\r\n                <a href="showExos">Affichage des exercices</a>\r\n            </div>\r\n        </li>\r\n        <li class="dropdown">\r\n            <a href="javascript:void(0)" class="dropbtn">Suppression</a>\r\n            <div class="dropdown-content">\r\n                <a href="suppressionExo">Supprimer un exercices</a>\r\n                <a href="suppressionSeance">Supprimer une séance</a>\r\n            </div>\r\n        </li>        <li><a href="inscription">Inscription</a></li>\r\n    </ul>\r\n\r\n    <div class="container">\r\n        <h1>Formulaire de création</h1>\r\n\r\n        <form method="post" action="ajoutExo">\r\n            <label for="nom_exo">Nom de l\'exercice :</label>\r\n            <input type="text" id="nom" name="nom"><br>\r\n\r\n            <input type="submit" value="Ajouter la séance">\r\n        </form>\r\n')
        if message:
            __M_writer('            <p>')
            __M_writer(str(message))
            __M_writer('</p>\r\n')
        __M_writer('    </div>\r\n\r\n</body>\r\n</html>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "html/ajoutExo.html", "uri": "ajoutExo.html", "source_encoding": "utf-8", "line_map": {"16": 0, "22": 1, "23": 45, "24": 46, "25": 46, "26": 46, "27": 48, "33": 27}}
__M_END_METADATA
"""
