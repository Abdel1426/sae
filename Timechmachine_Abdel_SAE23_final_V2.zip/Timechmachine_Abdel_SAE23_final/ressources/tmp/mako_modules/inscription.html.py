# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1716497372.7464995
_enable_loop = True
_template_filename = 'html/inscription.html'
_template_uri = 'inscription.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        seances = context.get('seances', UNDEFINED)
        message = context.get('message', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <meta charset="UTF-8">\r\n    <link rel="stylesheet" type="text/css" href="../css/style2.css">\r\n    <title>Interface Web Club</title>\r\n</head>\r\n<body>\r\n    <ul>\r\n        <li><a href="/">Accueil</a></li>\r\n        <li class="dropdown">\r\n            <a href="javascript:void(0)" class="dropbtn">Création</a>\r\n            <div class="dropdown-content">\r\n                <a href="ajoutExo">Ajouter un exercice</a>\r\n                <a href="ajoutSeance">Ajouter une séance</a>\r\n            </div>\r\n        </li>\r\n        <li class="dropdown">\r\n            <a href="javascript:void(0)" class="dropbtn">Affichage</a>\r\n            <div class="dropdown-content">\r\n                <a href="listeSeance">Affichage des séances</a>\r\n                <a href="showExos">Affichage des exercices</a>\r\n            </div>\r\n        </li>\r\n        <li class="dropdown">\r\n            <a href="javascript:void(0)" class="dropbtn">Suppression</a>\r\n            <div class="dropdown-content">\r\n                <a href="suppressionExo">Supprimer un exercice</a>\r\n                <a href="suppressionSeance">Supprimer une séance</a>\r\n            </div>\r\n        </li>\r\n        <li><a href="inscription">Inscription</a></li>\r\n    </ul>\r\n    <div class="container">\r\n        <h2>Inscription à la Soirée d\'Entraînement</h2>\r\n        <form id="registrationForm" method="post" action="inscription">\r\n            <!-- Champ Nom -->\r\n            <div class="form-group">\r\n                <label for="nom">Nom :</label>\r\n                <input type="text" id="nom" name="nom" required>\r\n            </div>\r\n            <!-- Champ Prénom -->\r\n            <div class="form-group">\r\n                <label for="prenom">Prénom :</label>\r\n                <input type="text" id="prenom" name="prenom" required>\r\n            </div>\r\n            <!-- Sélection des Séances -->\r\n            <div class="form-group">\r\n                <label for="seance1">Séance 1 :</label>\r\n                <select id="seance1" name="seance1" required>\r\n')
        for seance in seances:
            __M_writer('                        <option value="')
            __M_writer(str(seance[0]))
            __M_writer('">')
            __M_writer(str(seance[1]))
            __M_writer(' - Matériel: ')
            __M_writer(str(seance[2]))
            __M_writer(', Durée: ')
            __M_writer(str(seance[6]))
            __M_writer(' minutes</option>\r\n')
        __M_writer('                </select>\r\n            </div>\r\n            <!-- Ajout du bouton de soumission à l\'intérieur du formulaire -->\r\n            <input type="submit" value="S\'inscrire">\r\n        </form>\r\n')
        if message:
            __M_writer('            <p>')
            __M_writer(str(message))
            __M_writer('</p>\r\n')
        __M_writer('    </div>\r\n</body>\r\n</html>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "html/inscription.html", "uri": "inscription.html", "source_encoding": "utf-8", "line_map": {"16": 0, "23": 1, "24": 51, "25": 52, "26": 52, "27": 52, "28": 52, "29": 52, "30": 52, "31": 52, "32": 52, "33": 52, "34": 54, "35": 59, "36": 60, "37": 60, "38": 60, "39": 62, "45": 39}}
__M_END_METADATA
"""
