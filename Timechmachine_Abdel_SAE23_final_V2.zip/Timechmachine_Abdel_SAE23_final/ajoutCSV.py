import pymysql
import sys
import os

file_path = "data.csv"
if not os.path.isfile(file_path):
    print("Erreur: Le fichier spécifié n'est pas présent.")
    sys.exit(1)

try:
    db = pymysql.connect(host='localhost', user='root', port=3306, password='', database='club')
    cursor = db.cursor()

    with open(file_path, "r", encoding='utf-8') as file:
        for line in file:
            data = line.strip().split(',')
            nomA, prenom, materiel, exo1, exo2, exo3, duree_seance = data

            num_exercices = []
            for nom_exo in [exo1, exo2, exo3]:
                sql_insert_exercice = "INSERT INTO exercice (nom) VALUES (%s)"
                cursor.execute(sql_insert_exercice, (nom_exo,))
                num_exercices.append(cursor.lastrowid)

            sql_insert_seance = "INSERT INTO seance (materiel, NumExercice_1, NumExercice_2, NumExercice_3, duree) VALUES (%s, %s, %s, %s, %s)"
            cursor.execute(sql_insert_seance, (materiel, num_exercices[0], num_exercices[1], num_exercices[2], duree_seance))
            numSeance = cursor.lastrowid

            sql_insert_adherent = "INSERT INTO adherent (nom, prenom, NumSeance) VALUES (%s, %s, %s)"
            cursor.execute(sql_insert_adherent, (nomA, prenom, numSeance))

    db.commit()
    db.close()

    print("Insertions effectuées avec succès.")

except pymysql.Error as e:
    print("Erreur lors de l'accès à la base de données :", e)

except Exception as e:
    print("Une erreur inattendue s'est produite :", e)
